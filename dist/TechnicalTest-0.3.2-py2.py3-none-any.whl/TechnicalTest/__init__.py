"""
TechnicalTest.

Marina Lacambra's Technical Test.
"""

__version__ = "0.3.2"
__author__ = 'Marina Lacambra'