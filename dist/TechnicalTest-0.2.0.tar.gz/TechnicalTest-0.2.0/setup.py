from setuptools import setup

setup(
    name='TechnicalTest',
    version='0.2.0',
    author='Marina Lacambra',
    author_email='marina.lacambra@gmail.com',
    packages=['TechnicalTest'],
    scripts=['./TechnicalTest/technical_test.py'],
    url='http://pypi.python.org/pypi/TechnicalTest/',
    description='Technical Test',
    long_description=open('README.md').read(),
    install_requires=["preprocessor", "nltk", "pandas", "sklearn"]
)