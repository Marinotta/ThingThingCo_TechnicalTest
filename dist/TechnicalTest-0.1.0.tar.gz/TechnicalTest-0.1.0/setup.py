from setuptools import setup

setup(
    name='TechnicalTest',
    version='0.1.0',
    author='Marina Lacambra',
    author_email='marina.lacambra@gmail.com',
    packages=['technical_test'],
    scripts=['technical_test/bin/technical_test/technical_test.py'],
    url='http://pypi.python.org/pypi/TechnicalTest/',
    description='Technical Test',
    long_description=open('README.txt').read(),
    install_requires=[
       ],
)