"""
TechnicalTest

Marina Lacambra's Technical Test
"""

__version__ = "0.1.1"
__author__ = 'Marina Lacambra'