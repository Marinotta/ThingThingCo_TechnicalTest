from setuptools import setup

setup(
    name='TechnicalTest',
    version='0.1.1',
    author='Marina Lacambra',
    author_email='marina.lacambra@gmail.com',
    packages=['technical_test'],
    scripts=['./technical_test/technical_test.py'],
    url='http://pypi.python.org/pypi/TechnicalTest/',
    description='Technical Test',
    long_description=open('README.md').read(),
    install_requires=["preprocessor", "nltk", "pandas", "sklearn"]
)